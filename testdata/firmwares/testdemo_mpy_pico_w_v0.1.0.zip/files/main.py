# TestDemo MicroPython app (synthetic)
# Flashed via CleepDesktop serial push for wizard testing.

def main():
    print("testdemo micropython-app ok")


if __name__ == "__main__":
    main()
